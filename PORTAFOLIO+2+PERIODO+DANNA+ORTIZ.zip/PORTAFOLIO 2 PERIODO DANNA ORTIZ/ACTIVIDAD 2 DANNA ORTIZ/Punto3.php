<!DOCTYPE html>
<html>
<head>
    <title>Lista de Tareas</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h1>Lista de Tareas Pendientes</h1>
    <ul>
        <?php include "tareas.php"; ?>
    </ul>
</body>
</html>